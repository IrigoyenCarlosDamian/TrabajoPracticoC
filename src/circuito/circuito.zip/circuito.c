#include <string.h>
#include <errno.h>

#include "../../config/config.h"
#include "../../lib/utils/utils.h"
#include "../../lib/orm/orm.h"
#include "circuito.h"

THIS(obj_circuito)
//----------------------------------------------------
//Copiar a puntero de arreglo en posicion dada, desde un result set de base de datos.
static void fillCircuitoFromDB(void **rw , int rowi,PGresult *res)
{
    t_circuito *dscircuito;
    dscircuito = &(( (t_circuito *) *rw)[rowi]);
    //leer valor desde estructura obtenida de la BD    
	dscircuito->circuito_id = atoi(PQgetvalue(res,rowi,0));
	strcpy( dscircuito->letra ,rtrim(PQgetvalue(res,rowi,1),' '));
    dscircuito->secc_id = atoi(PQgetvalue(res,rowi,2));
    strcpy( dscircuito->nombre_circuito ,rtrim(PQgetvalue(res,rowi,3),' '));
    dscircuito->localidad_id = atoi(PQgetvalue(res,rowi,4));
}       
//----------------------------------------------------
//Copiar datos desde una variable de struct => puntero a obj_circuito
static void fillObjCircuito(obj_circuito *p,  t_circuito rwitm)
{  
    p->info.circuito_id = rwitm.circuito_id;
	strcpy( p->info.letra ,rwitm.letra);
	p->info.secc_id = rwitm.secc_id;
	strcpy( p->info.nombre_circuito,rwitm.nombre_circuito);
    p->info.localidad_id = rwitm.localidad_id;	  
	p->isNewObj = false; // marcar que ya existe correspondencia en la base de datos en saveObj
}
//----------------------------------------------------
//Copiar en arreglo dinamico de tipo obj_circuito
static void fillRowsCircuito(void **list, int size,void *data)
{
     int i;
     obj_circuito *d;
     // pedir memoria para el listado en memoria de circuitos obj_circuito
    *list = (obj_circuito **)malloc(sizeof(obj_circuito*)* size);
    for(i=0;i<size;++i)
    {
      d = circuito_new();
      fillObjCircuito(d,((t_circuito *)data)[i]);
      ((obj_circuito **)*list)[i] = d;
    }
 }
//----------------------------------------------------
//Copiar las tuplas a una instancia de dataset:t_table
static void fill_dataset_circuito(t_table *t,void *data, int sz)
{
 int i;
 //pedir memoria para contener listado de registros en formato dataset_circuito.
 t->rows = malloc(sizeof(t_circuito)* sz);
 t->cant_rows=sz;//cantidad de filas
     for(i=0;i<sz;++i)
     {
      ((t_circuito *)t->rows)[i].circuito_id =((t_circuito *)data)[i].circuito_id;
      strcpy( ((t_circuito *)t->rows)[i].letra,((t_circuito *)data)[i].letra);
      ((t_circuito *)t->rows)[i].secc_id =((t_circuito *)data)[i].secc_id;
      strcpy( ((t_circuito *)t->rows)[i].nombre_circuito,((t_circuito *)data)[i].nombre_circuito);
      ((t_circuito *)t->rows)[i].localidad_id =((t_circuito *)data)[i].localidad_id;
     }
}
//----------------------------------------------------
//ejecutar consulta SQL en la base y obtener result set para cargar en memoria, invocacion personalizada a un codigo generico.
static int exec_get_circuito(char *sql,void **rw)
{
  return exec_get_fromDB(sql,rw, sizeof(t_circuito),fillCircuitoFromDB);
}
//----------------------------------------------------
// implementacion para copiar toda la informacion segun un criterio ejecutado en la base de datos
static int findAll_circuitoImpl(void *self,void **list, char *criteria)
{
  return findAllImpl(self,list, criteria, sizeof(t_circuito), ((t_table*)((obj_circuito*)self)->ds)->rows,fillCircuitoFromDB,fillRowsCircuito);
}
//----------------------------------------------------
static bool getIsNewObj_Impl(void *self)
{
	obj_circuito *obj = this(self);
	return obj->isNewObj;
}
//----------------------------------------------------
// implementacion de metodos para circuito
static int find_circuitoImpl(void *self, int k) // se debe pasar en orden de aparicion de las columnas claves 
{
   int size=0; void *data;  
   char *sql;
   obj_circuito *obj = this(self);
   //obtener cadena sql (select * from table where ...)las columnas claves estan igualadas a datos.   
   obj->info.circuito_id=k;//setear dato clave
   sql = (char*)getFindByKeySQL((t_object*)self);
   //ejecutar consulta sql de seleccion, con criterio where
   data = ((t_table*)obj->ds)->rows;   
   size = exec_get_circuito(sql,&data);
   //liberar cadena sql
   free(sql);
   // completar 
   fill_dataset_circuito(obj->ds,data,size);
   // setear datos a la instancia....
   if(size>0)
   	 fillObjCircuito(obj,((t_circuito *)data)[0]);
   else
     size = -1;   
   return size;
}
//----------------------------------------------------
static bool saveObj_circuitoImpl(void *self)
{
   obj_circuito *obj = this(self); 
   int newIdCircuito;
   bool isNew_Obj = obj->getIsNewObj(self);
   bool retValue = saveObjImpl(self,&newIdCircuito);
   if(isNew_Obj)
     obj->info.circuito_id = newIdCircuito;
   return retValue;
}
//----------------------------------------------------
static void toString_circuitoImpl(void *self)
{
     obj_circuito *self_o=this(self);
     obj_circuito *sup;     
     printf("circuito_id: %d  circuito:%s  - letra:%s \n",self_o->info.circuito_id,self_o->info.nombre_circuito,self_o->info.letra);
}
//----------------------------------------------------
//implementacion de getters
static int getCircuitoId_Impl(void *self)
{ 
  obj_circuito *obj = this(self);
  return obj->info.circuito_id;
}
//----------------------------------------------------
static char *getNombreCircuito_Impl(void *self)
{
	obj_circuito *obj = this(self);
	return obj->info.nombre_circuito;	
}
//----------------------------------------------------
//implementacion setters
//----------------------------------------------------
static void setNombreCircuito_Impl(void *self,char *nombre_circuito)
{ 
	obj_circuito *obj = this(self);
	strcpy(obj->info.nombre_circuito,nombre_circuito);
}
//----------------------------------------------------
static void getValueByPosImpl(void *self,char * cad, int pos)
{ 
   char field[MAX_WHERE_SQL];
   obj_circuito *obj = this(self);
   t_table *tt=obj->ds;
   if(pos==0)
     snprintf( field, MAX_WHERE_SQL,"%d", obj->info.circuito_id );
   if(pos==1)
     snprintf( field, MAX_WHERE_SQL,"'%s'", obj->info.nombre_circuito );
   strcat(cad,field);   
}
//----------------------------------------------------
static void *init_circuito(void *self)
{
  obj_circuito *obj = (obj_circuito *)self;   
  //setear valores default
  obj->info.circuito_id=0;
  CLEAR(obj->info.nombre_circuito,MAX);
  obj->ds  = &table_circuito;  
  obj->isNewObj = true;//marcar como objeto nuevo, si se crea nueva instancia
  obj->getValueByPos = getValueByPosImpl;
  // Inicializar handlers de getters y setters
  /// getters
  obj->getCircuitoId  	  = getCircuitoId_Impl;
  obj->getNombreCircuito = getNombreCircuito_Impl;  
  /// setters  
  obj->setNombreCircuito = setNombreCircuito_Impl;  
  //incializacion de la interfaz de la entidad
  obj->getIsNewObj =   getIsNewObj_Impl;
  obj->findbykey = find_circuitoImpl;
  obj->findAll =   findAll_circuitoImpl;
  obj->saveObj =   saveObj_circuitoImpl; 
  obj->toString =   toString_circuitoImpl;
  return obj;
}
//----------------------------------------------------
//constructor de circuito
obj_circuito *circuito_new()
{
  return (obj_circuito *)init_obj(sizeof(obj_circuito), init_circuito);
}
//----------------------------------------------------
