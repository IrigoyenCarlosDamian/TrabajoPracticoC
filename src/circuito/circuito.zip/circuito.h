#ifndef CIRC_INCLUDED
#define CIRC_INCLUDED
#define CNT_COL_CIRC 5
#define MAXLET 2
   
typedef struct {   
    int circuito_id;
	char letra[MAXLET];
	int secc_id;
    char nombre_circuito[MAX];
	int localidad_id;
} t_circuito;
//----------------------------------------------------
typedef struct {
    t_table *ds;
    int  (*findAll)(void *self, void **list,char *criteria); 
    void (*toString)(void *self);
	bool (*getIsNewObj)(void *self);
    bool (*saveObj)(void *self);
	void (*destroyInternal)(void *self);
	void (*getValueByPos)(void *self,char *cad, int pos);
	bool isNewObj;
	//// FIN CORRESPONDENCIA COMUN CON t_object
    int (*findbykey)(void *self,int circuito_id);
    //-- getters
    int (*getCircuitoId)(void *self);
    char *(*getLetraCircuito)(void *self);
    int (*getSeccionId)(void *self);
    char *(*getNombreCircuito)(void *self);
    int (*getLocalidadId)(void *self);
    //-- setters
    void (*setLetraCircuito)(void *self,char *Letra);
    void (*setNombreCircuito)(void *self,char *NombreCircuito);
    void (*setSeccionId)(void *self,int idSeccion);
    void (*setLocalidadId)(void *self,int idLocalidad);
    //estructura estatica
    t_circuito info;    
}obj_circuito;
// funcionalidad publica que se implementa en circuito.c
extern obj_circuito *circuito_new ();
// meta data para acceder a las circuitos
static t_column cols_circuito[CNT_COL_CIRC]={ {"id",t_int,4,true,true}, {"letra",t_varchar,1,false,false},{"secc_id",t_int,4,false,false}, {"nombre",t_varchar,50,false,false},{"localidad_id",t_int,4,false,false}};
// plantilla para la circuito.
static t_table table_circuito={"circuito",CNT_COL_CIRC,0, cols_circuito,NULL};
#endif
