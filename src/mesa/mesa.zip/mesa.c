#include <string.h>
#include <errno.h>

#include "../../config/config.h"
#include "../../lib/utils/utils.h"
#include "../../lib/orm/orm.h"
#include "mesa.h"

THIS(obj_mesa)
//----------------------------------------------------
//Copiar a puntero de arreglo en posicion dada, desde un result set de base de datos.
static void fillMesaFromDB(void **rw , int rowi,PGresult *res)
{
    t_mesa *dsmesa;
    dsmesa = &(( (t_mesa *) *rw)[rowi]);
    //leer valor desde estructura obtenida de la BD    
	dsmesa->mesa_id = atoi(PQgetvalue(res,rowi,0));
	dsmesa->nro_mesa = atoi(PQgetvalue(res,rowi,1));
	dsmesa->circ_id = atoi(PQgetvalue(res,rowi,2));
	dsmesa->esc_id = atoi(PQgetvalue(res,rowi,3));
}       
//----------------------------------------------------
//Copiar datos desde una variable de struct => puntero a obj_mesa
static void fillObjMesa(obj_mesa *p,  t_mesa rwitm)
{  
      p->info.mesa_id = rwitm.mesa_id;
      p->info.nro_mesa = rwitm.nro_mesa;
      p->info.circ_id = rwitm.circ_id;
      p->info.esc_id = rwitm.esc_id;
	  p->isNewObj = false; // marcar que ya existe correspondencia en la base de datos en saveObj
}
//----------------------------------------------------
//Copiar en arreglo dinamico de tipo obj_mesa
static void fillRowsMesa(void **list, int size,void *data)
{
     int i;
     obj_mesa *d;
     // pedir memoria para el listado en memoria de mesas obj_mesa
    *list = (obj_mesa **)malloc(sizeof(obj_mesa*)* size);
    for(i=0;i<size;++i)
    {
      d = mesa_new();
      fillObjMesa(d,((t_mesa *)data)[i]);
      ((obj_mesa **)*list)[i] = d;
    }
 }
//----------------------------------------------------
//Copiar las tuplas a una instancia de dataset:t_table
static void fill_dataset_mesa(t_table *t,void *data, int sz)
{
 int i;
 //pedir memoria para contener listado de registros en formato dataset_mesa.
 t->rows = malloc(sizeof(t_mesa)* sz);
 t->cant_rows=sz;//cantidad de filas
     for(i=0;i<sz;++i)
     {
      ((t_mesa *)t->rows)[i].mesa_id =((t_mesa *)data)[i].mesa_id;
      ((t_mesa *)t->rows)[i].nro_mesa =((t_mesa *)data)[i].nro_mesa;
      ((t_mesa *)t->rows)[i].circ_id =((t_mesa *)data)[i].circ_id;
      ((t_mesa *)t->rows)[i].esc_id =((t_mesa *)data)[i].esc_id;
     }
}
//----------------------------------------------------
//ejecutar consulta SQL en la base y obtener result set para cargar en memoria, invocacion personalizada a un codigo generico.
static int exec_get_mesa(char *sql,void **rw)
{
  return exec_get_fromDB(sql,rw, sizeof(t_mesa),fillMesaFromDB);
}
//----------------------------------------------------
// implementacion para copiar toda la informacion segun un criterio ejecutado en la base de datos
static int findAll_mesaImpl(void *self,void **list, char *criteria)
{
  return findAllImpl(self,list, criteria, sizeof(t_mesa), ((t_table*)((obj_mesa*)self)->ds)->rows,fillMesaFromDB,fillRowsMesa);
}
//----------------------------------------------------
static bool getIsNewObj_Impl(void *self)
{
	obj_mesa *obj = this(self);
	return obj->isNewObj;
}
//----------------------------------------------------
// implementacion de metodos para mesa
static int find_mesaImpl(void *self, int k) // se debe pasar en orden de aparicion de las columnas claves 
{
   int size=0; void *data;  
   char *sql;
   obj_mesa *obj = this(self);
   //obtener cadena sql (select * from table where ...)las columnas claves estan igualadas a datos.   
   obj->info.mesa_id=k;//setear dato clave
   sql = (char*)getFindByKeySQL((t_object*)self);
   //ejecutar consulta sql de seleccion, con criterio where
   data = ((t_table*)obj->ds)->rows;   
   size = exec_get_mesa(sql,&data);
   //liberar cadena sql
   free(sql);
   // completar 
   fill_dataset_mesa(obj->ds,data,size);
   // setear datos a la instancia....
   if(size>0)
   	 fillObjMesa(obj,((t_mesa *)data)[0]);
   else
     size = -1;   
   return size;
}
//----------------------------------------------------
static bool saveObj_mesaImpl(void *self)
{
   obj_mesa *obj = this(self); 
   int newIdMesa;
   bool isNew_Obj = obj->getIsNewObj(self);
   bool retValue = saveObjImpl(self,&newIdMesa);
   if(isNew_Obj)
     obj->info.mesa_id = newIdMesa;
   return retValue;
}
//----------------------------------------------------
static void toString_mesaImpl(void *self)
{
     obj_mesa *self_o=this(self);
     obj_mesa *sup;     
     printf("mesa_id: %d  nro mesa:%d \n",self_o->info.mesa_id,self_o->info.nro_mesa);
}
//----------------------------------------------------
//implementacion de getters
static int getMesaId_Impl(void *self)
{ 
  obj_mesa *obj = this(self);
  return obj->info.mesa_id;
}
//----------------------------------------------------
static int getNroMesa_Impl(void *self)
{ 
  obj_mesa *obj = this(self);
  return obj->info.nro_mesa;
}
//----------------------------------------------------
static int getCircuitoId_Impl(void *self)
{
	obj_mesa *obj = this(self);
	return obj->info.circ_id;	
}
//----------------------------------------------------
static int getEscuelaId_Impl(void *self)
{
	obj_mesa *obj = this(self);
	return obj->info.esc_id;	
}
//----------------------------------------------------
//implementacion setters
//----------------------------------------------------
static void setNroMesa_Impl(void *self,int Nro_mesa)
{ 
	obj_mesa *obj = this(self);
	obj->info.nro_mesa = Nro_mesa;
}
//----------------------------------------------------
static void setCircuitoId_Impl(void *self,int CircuitoId)
{ 
	obj_mesa *obj = this(self);
	obj->info.circ_id = CircuitoId;
}
//----------------------------------------------------
static void setEscuelaId_Impl(void *self,int EscuelaId)
{ 
	obj_mesa *obj = this(self);
	obj->info.esc_id = EscuelaId;
}
//----------------------------------------------------
static void getValueByPosImpl(void *self,char * cad, int pos)
{ 
   char field[MAX_WHERE_SQL];
   obj_mesa *obj = this(self);
   t_table *tt=obj->ds;
   if(pos==0)
     snprintf( field, MAX_WHERE_SQL,"%d", obj->info.mesa_id );
/*   if(pos==1)
     snprintf( field, MAX_WHERE_SQL,"'%s'", obj->info.nombre_mesa );*/
   strcat(cad,field);   
}
//----------------------------------------------------
static void *init_mesa(void *self)
{
  obj_mesa *obj = (obj_mesa *)self;   
  //setear valores default
  obj->info.mesa_id=0;
  obj->info.nro_mesa=0;
  obj->ds  = &table_mesa;  
  obj->isNewObj = true;//marcar como objeto nuevo, si se crea nueva instancia
  obj->getValueByPos = getValueByPosImpl;
  // Inicializar handlers de getters y setters
  /// getters
  obj->getMesaId  	  = getMesaId_Impl;
  obj->getNroMesa = getNroMesa_Impl;  
  obj->getCircuitoId = getCircuitoId_Impl;
  obj->getEscuelaId = getEscuelaId_Impl;
  /// setters  
  obj->setNroMesa = setNroMesa_Impl;
  obj->setCircuitoId = setCircuitoId_Impl;
  obj->setEscuelaId = setEscuelaId_Impl;
  //incializacion de la interfaz de la entidad
  obj->getIsNewObj =   getIsNewObj_Impl;
  obj->findbykey = find_mesaImpl;
  obj->findAll =   findAll_mesaImpl;
  obj->saveObj =   saveObj_mesaImpl; 
  obj->toString =   toString_mesaImpl;
  return obj;
}
//----------------------------------------------------
//constructor de mesa
obj_mesa *mesa_new()
{
  return (obj_mesa *)init_obj(sizeof(obj_mesa), init_mesa);
}
//----------------------------------------------------
