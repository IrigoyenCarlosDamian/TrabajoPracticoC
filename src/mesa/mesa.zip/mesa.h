#ifndef MESA_INCLUDED
#define MESA_INCLUDED
#define CNT_COL_MESA 4
   
typedef struct {   
	int mesa_id;
	int nro_mesa;
	int circ_id;
	int esc_id;
} t_mesa;
//----------------------------------------------------
typedef struct {
	t_table *ds;
	int  (*findAll)(void *self, void **list,char *criteria); 
	void (*toString)(void *self);
	bool (*getIsNewObj)(void *self);
	bool (*saveObj)(void *self);
	void (*destroyInternal)(void *self);
	void (*getValueByPos)(void *self,char *cad, int pos);
	bool isNewObj;
	//// FIN CORRESPONDENCIA COMUN CON t_object
	int (*findbykey)(void *self,int mesa_id);
	//-- getters
	int (*getMesaId)(void *self);
	int (*getNroMesa)(void *self);
	int (*getCircuitoId)(void *self);
	int (*getEscuelaId)(void *self);
	//-- setters
	void (*setNroMesa)(void *self,int);
	void (*setCircuitoId)(void *self,int);
	void (*setEscuelaId)(void *self,int);
	//estructura estatica
	t_mesa info;    
}obj_mesa;
// funcionalidad publica que se implementa en mesa.c
extern obj_mesa *mesa_new ();
// meta data para acceder a las mesas
static t_column cols_mesa[CNT_COL_MESA]={ {"id",t_int,4,true,true},{"nro_mesa",t_int,4,false,false},{"circ_id",t_int,4,false,false},{"esc_id",t_int,4,false,false}};
// plantilla para la mesa.
static t_table table_mesa={"mesa",CNT_COL_MESA,0, cols_mesa,NULL};
#endif
