#ifndef CAT_INCLUDED
#define CAT_INCLUDED
#define CNT_COL_CAT 2
   
typedef struct {   
    int categoria_id;
    char nombre_categoria[MAX];
} t_categoria;
//----------------------------------------------------
typedef struct {
    t_table *ds;
    int  (*findAll)(void *self, void **list,char *criteria); 
    void (*toString)(void *self);
	bool (*getIsNewObj)(void *self);
    bool (*saveObj)(void *self);
	void (*destroyInternal)(void *self);
	void (*getValueByPos)(void *self,char *cad, int pos);
	bool isNewObj;
	//// FIN CORRESPONDENCIA COMUN CON t_object
    int (*findbykey)(void *self,int categoria_id);
    //-- getters
    int (*getCategoriaId)(void *self);
    char *(*getNombreCategoria)(void *self);
    //-- setters
    void (*setNombreCategoria)(void *self,char *NombreCategoria);
    //estructura estatica
    t_categoria info;    
}obj_categoria;
// funcionalidad publica que se implementa en categoria.c
extern obj_categoria *categoria_new ();
// meta data para acceder a las categorias
static t_column cols_categoria[CNT_COL_CAT]={ {"id",t_int,4,true,true}, {"nom_categoria",t_varchar,30,false,false}};
// plantilla para la categoria.
static t_table table_categoria={"categ_eleccion",CNT_COL_CAT,0, cols_categoria,NULL};
#endif
