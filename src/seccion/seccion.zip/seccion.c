#include <string.h>
#include <errno.h>

#include "../../config/config.h"
#include "../../lib/utils/utils.h"
#include "../../lib/orm/orm.h"
#include "seccion.h"

THIS(obj_seccion)
//----------------------------------------------------
//Copiar a puntero de arreglo en posicion dada, desde un result set de base de datos.
static void fillSeccionFromDB(void **rw , int rowi,PGresult *res)
{
    t_seccion *dsseccion;
    dsseccion = &(( (t_seccion *) *rw)[rowi]);
    //leer valor desde estructura obtenida de la BD    
	dsseccion->seccion_id = atoi(PQgetvalue(res,rowi,0));
    strcpy( dsseccion->nombre_seccion ,rtrim(PQgetvalue(res,rowi,1),' '));
}       
//----------------------------------------------------
//Copiar datos desde una variable de struct => puntero a obj_seccion
static void fillObjSeccion(obj_seccion *p,  t_seccion rwitm)
{  
      p->info.seccion_id = rwitm.seccion_id;
	  strcpy( p->info.nombre_seccion,rwitm.nombre_seccion);
	  p->isNewObj = false; // marcar que ya existe correspondencia en la base de datos en saveObj
}
//----------------------------------------------------
//Copiar en arreglo dinamico de tipo obj_seccion
static void fillRowsSeccion(void **list, int size,void *data)
{
     int i;
     obj_seccion *d;
     // pedir memoria para el listado en memoria de seccions obj_seccion
    *list = (obj_seccion **)malloc(sizeof(obj_seccion*)* size);
    for(i=0;i<size;++i)
    {
      d = seccion_new();
      fillObjSeccion(d,((t_seccion *)data)[i]);
      ((obj_seccion **)*list)[i] = d;
    }
 }
//----------------------------------------------------
//Copiar las tuplas a una instancia de dataset:t_table
static void fill_dataset_seccion(t_table *t,void *data, int sz)
{
 int i;
 //pedir memoria para contener listado de registros en formato dataset_seccion.
 t->rows = malloc(sizeof(t_seccion)* sz);
 t->cant_rows=sz;//cantidad de filas
     for(i=0;i<sz;++i)
     {
      ((t_seccion *)t->rows)[i].seccion_id =((t_seccion *)data)[i].seccion_id;
      strcpy( ((t_seccion *)t->rows)[i].nombre_seccion,((t_seccion *)data)[i].nombre_seccion);
     }
}
//----------------------------------------------------
//ejecutar consulta SQL en la base y obtener result set para cargar en memoria, invocacion personalizada a un codigo generico.
static int exec_get_seccion(char *sql,void **rw)
{
  return exec_get_fromDB(sql,rw, sizeof(t_seccion),fillSeccionFromDB);
}
//----------------------------------------------------
// implementacion para copiar toda la informacion segun un criterio ejecutado en la base de datos
static int findAll_seccionImpl(void *self,void **list, char *criteria)
{
  return findAllImpl(self,list, criteria, sizeof(t_seccion), ((t_table*)((obj_seccion*)self)->ds)->rows,fillSeccionFromDB,fillRowsSeccion);
}
//----------------------------------------------------
static bool getIsNewObj_Impl(void *self)
{
	obj_seccion *obj = this(self);
	return obj->isNewObj;
}
//----------------------------------------------------
// implementacion de metodos para seccion
static int find_seccionImpl(void *self, int k) // se debe pasar en orden de aparicion de las columnas claves 
{
   int size=0; void *data;  
   char *sql;
   obj_seccion *obj = this(self);
   //obtener cadena sql (select * from table where ...)las columnas claves estan igualadas a datos.   
   obj->info.seccion_id=k;//setear dato clave
   sql = (char*)getFindByKeySQL((t_object*)self);
   //ejecutar consulta sql de seleccion, con criterio where
   data = ((t_table*)obj->ds)->rows;   
   size = exec_get_seccion(sql,&data);
   //liberar cadena sql
   free(sql);
   // completar 
   fill_dataset_seccion(obj->ds,data,size);
   // setear datos a la instancia....
   if(size>0)
   	 fillObjSeccion(obj,((t_seccion *)data)[0]);
   else
     size = -1;   
   return size;
}
//----------------------------------------------------
static bool saveObj_seccionImpl(void *self)
{
   obj_seccion *obj = this(self); 
   int newIdSeccion;
   bool isNew_Obj = obj->getIsNewObj(self);
   bool retValue = saveObjImpl(self,&newIdSeccion);
   if(isNew_Obj)
     obj->info.seccion_id = newIdSeccion;
   return retValue;
}
//----------------------------------------------------
static void toString_seccionImpl(void *self)
{
     obj_seccion *self_o=this(self);
     obj_seccion *sup;     
     printf("seccion_id: %d  seccion:%s \n",self_o->info.seccion_id,self_o->info.nombre_seccion);
}
//----------------------------------------------------
//implementacion de getters
static int getSeccionId_Impl(void *self)
{ 
  obj_seccion *obj = this(self);
  return obj->info.seccion_id;
}
//----------------------------------------------------
static char *getNombreSeccion_Impl(void *self)
{
	obj_seccion *obj = this(self);
	return obj->info.nombre_seccion;	
}
//----------------------------------------------------
//implementacion setters
//----------------------------------------------------
static void setNombreSeccion_Impl(void *self,char *nombre_seccion)
{ 
	obj_seccion *obj = this(self);
	strcpy(obj->info.nombre_seccion,nombre_seccion);
}
//----------------------------------------------------
static void getValueByPosImpl(void *self,char * cad, int pos)
{ 
   char field[MAX_WHERE_SQL];
   obj_seccion *obj = this(self);
   t_table *tt=obj->ds;
   if(pos==0)
     snprintf( field, MAX_WHERE_SQL,"%d", obj->info.seccion_id );
   if(pos==1)
     snprintf( field, MAX_WHERE_SQL,"'%s'", obj->info.nombre_seccion );
   strcat(cad,field);   
}
//----------------------------------------------------
static void *init_seccion(void *self)
{
  obj_seccion *obj = (obj_seccion *)self;   
  //setear valores default
  obj->info.seccion_id=0;
  CLEAR(obj->info.nombre_seccion,MAX);
  obj->ds  = &table_seccion;  
  obj->isNewObj = true;//marcar como objeto nuevo, si se crea nueva instancia
  obj->getValueByPos = getValueByPosImpl;
  // Inicializar handlers de getters y setters
  /// getters
  obj->getSeccionId  	  = getSeccionId_Impl;
  obj->getNombreSeccion = getNombreSeccion_Impl;  
  /// setters  
  obj->setNombreSeccion = setNombreSeccion_Impl;  
  //incializacion de la interfaz de la entidad
  obj->getIsNewObj =   getIsNewObj_Impl;
  obj->findbykey = find_seccionImpl;
  obj->findAll =   findAll_seccionImpl;
  obj->saveObj =   saveObj_seccionImpl; 
  obj->toString =   toString_seccionImpl;
  return obj;
}
//----------------------------------------------------
//constructor de seccion
obj_seccion *seccion_new()
{
  return (obj_seccion *)init_obj(sizeof(obj_seccion), init_seccion);
}
//----------------------------------------------------
