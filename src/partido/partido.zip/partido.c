#include <string.h>
#include <errno.h>

#include "../../config/config.h"
#include "../../lib/utils/utils.h"
#include "../../lib/orm/orm.h"
#include "partido.h"

THIS(obj_partido)
//----------------------------------------------------
//Copiar a puntero de arreglo en posicion dada, desde un result set de base de datos.
static void fillPartidoFromDB(void **rw , int rowi,PGresult *res)
{
    t_partido *dspartido;
    dspartido = &(( (t_partido *) *rw)[rowi]);
    //leer valor desde estructura obtenida de la BD    
	dspartido->partido_id = atoi(PQgetvalue(res,rowi,0));
	dspartido->nro_partido = atoi(PQgetvalue(res,rowi,1));
    strcpy( dspartido->nombre_partido ,rtrim(PQgetvalue(res,rowi,2),' '));
    strcpy( dspartido->color ,rtrim(PQgetvalue(res,rowi,3),' '));
}       
//----------------------------------------------------
//Copiar datos desde una variable de struct => puntero a obj_partido
static void fillObjPartido(obj_partido *p,  t_partido rwitm)
{  
      p->info.partido_id = rwitm.partido_id;
      p->info.nro_partido = rwitm.nro_partido;
	  strcpy( p->info.nombre_partido,rwitm.nombre_partido);
	  strcpy( p->info.color,rwitm.color);
	  p->isNewObj = false; // marcar que ya existe correspondencia en la base de datos en saveObj
}
//----------------------------------------------------
//Copiar en arreglo dinamico de tipo obj_partido
static void fillRowsPartido(void **list, int size,void *data)
{
     int i;
     obj_partido *d;
     // pedir memoria para el listado en memoria de partidos obj_partido
    *list = (obj_partido **)malloc(sizeof(obj_partido*)* size);
    for(i=0;i<size;++i)
    {
      d = partido_new();
      fillObjPartido(d,((t_partido *)data)[i]);
      ((obj_partido **)*list)[i] = d;
    }
 }
//----------------------------------------------------
//Copiar las tuplas a una instancia de dataset:t_table
static void fill_dataset_partido(t_table *t,void *data, int sz)
{
 int i;
 //pedir memoria para contener listado de registros en formato dataset_partido.
 t->rows = malloc(sizeof(t_partido)* sz);
 t->cant_rows=sz;//cantidad de filas
     for(i=0;i<sz;++i)
     {
      ((t_partido *)t->rows)[i].partido_id =((t_partido *)data)[i].partido_id;
      ((t_partido *)t->rows)[i].nro_partido =((t_partido *)data)[i].nro_partido;
      strcpy( ((t_partido *)t->rows)[i].nombre_partido,((t_partido *)data)[i].nombre_partido);
      strcpy( ((t_partido *)t->rows)[i].color,((t_partido *)data)[i].color);
     }
}
//----------------------------------------------------
//ejecutar consulta SQL en la base y obtener result set para cargar en memoria, invocacion personalizada a un codigo generico.
static int exec_get_partido(char *sql,void **rw)
{
  return exec_get_fromDB(sql,rw, sizeof(t_partido),fillPartidoFromDB);
}
//----------------------------------------------------
// implementacion para copiar toda la informacion segun un criterio ejecutado en la base de datos
static int findAll_partidoImpl(void *self,void **list, char *criteria)
{
  return findAllImpl(self,list, criteria, sizeof(t_partido), ((t_table*)((obj_partido*)self)->ds)->rows,fillPartidoFromDB,fillRowsPartido);
}
//----------------------------------------------------
static bool getIsNewObj_Impl(void *self)
{
	obj_partido *obj = this(self);
	return obj->isNewObj;
}
//----------------------------------------------------
// implementacion de metodos para partido
static int find_partidoImpl(void *self, int k) // se debe pasar en orden de aparicion de las columnas claves 
{
   int size=0; void *data;  
   char *sql;
   obj_partido *obj = this(self);
   //obtener cadena sql (select * from table where ...)las columnas claves estan igualadas a datos.   
   obj->info.partido_id=k;//setear dato clave
   sql = (char*)getFindByKeySQL((t_object*)self);
   //ejecutar consulta sql de seleccion, con criterio where
   data = ((t_table*)obj->ds)->rows;   
   size = exec_get_partido(sql,&data);
   //liberar cadena sql
   free(sql);
   // completar 
   fill_dataset_partido(obj->ds,data,size);
   // setear datos a la instancia....
   if(size>0)
   	 fillObjPartido(obj,((t_partido *)data)[0]);
   else
     size = -1;   
   return size;
}
//----------------------------------------------------
static bool saveObj_partidoImpl(void *self)
{
   obj_partido *obj = this(self); 
   int newIdPartido;
   bool isNew_Obj = obj->getIsNewObj(self);
   bool retValue = saveObjImpl(self,&newIdPartido);
   if(isNew_Obj)
     obj->info.partido_id = newIdPartido;
   return retValue;
}
//----------------------------------------------------
static void toString_partidoImpl(void *self)
{
     obj_partido *self_o=this(self);
     obj_partido *sup;     
     printf("partido_id: %d  partido:%s \n",self_o->info.partido_id,self_o->info.nombre_partido);
}
//----------------------------------------------------
//implementacion de getters
static int getPartidoId_Impl(void *self)
{ 
  obj_partido *obj = this(self);
  return obj->info.partido_id;
}
//----------------------------------------------------
static char *getNombrePartido_Impl(void *self)
{
	obj_partido *obj = this(self);
	return obj->info.nombre_partido;	
}
//----------------------------------------------------
//implementacion setters
//----------------------------------------------------
static void setNombrePartido_Impl(void *self,char *nombre_partido)
{ 
	obj_partido *obj = this(self);
	strcpy(obj->info.nombre_partido,nombre_partido);
}
//----------------------------------------------------
static void getValueByPosImpl(void *self,char * cad, int pos)
{ 
   char field[MAX_WHERE_SQL];
   obj_partido *obj = this(self);
   t_table *tt=obj->ds;
   if(pos==0)
     snprintf( field, MAX_WHERE_SQL,"%d", obj->info.partido_id );
   if(pos==1)
     snprintf( field, MAX_WHERE_SQL,"'%s'", obj->info.nombre_partido );
   strcat(cad,field);   
}
//----------------------------------------------------
static void *init_partido(void *self)
{
  obj_partido *obj = (obj_partido *)self;   
  //setear valores default
  obj->info.partido_id=0;
  CLEAR(obj->info.nombre_partido,MAX);
  obj->ds  = &table_partido;  
  obj->isNewObj = true;//marcar como objeto nuevo, si se crea nueva instancia
  obj->getValueByPos = getValueByPosImpl;
  // Inicializar handlers de getters y setters
  /// getters
  obj->getPartidoId  	  = getPartidoId_Impl;
  obj->getNombrePartido = getNombrePartido_Impl;  
  /// setters  
  obj->setNombrePartido = setNombrePartido_Impl;  
  //incializacion de la interfaz de la entidad
  obj->getIsNewObj =   getIsNewObj_Impl;
  obj->findbykey = find_partidoImpl;
  obj->findAll =   findAll_partidoImpl;
  obj->saveObj =   saveObj_partidoImpl; 
  obj->toString =   toString_partidoImpl;
  return obj;
}
//----------------------------------------------------
//constructor de partido
obj_partido *partido_new()
{
  return (obj_partido *)init_obj(sizeof(obj_partido), init_partido);
}
//----------------------------------------------------
