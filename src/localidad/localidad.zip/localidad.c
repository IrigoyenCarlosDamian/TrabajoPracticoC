#include <string.h>
#include <errno.h>

#include "../../config/config.h"
#include "../../lib/utils/utils.h"
#include "../../lib/orm/orm.h"
#include "localidad.h"

THIS(obj_localidad)
//----------------------------------------------------
//Copiar a puntero de arreglo en posicion dada, desde un result set de base de datos.
static void fillLocalidadFromDB(void **rw , int rowi,PGresult *res)
{
    t_localidad *dslocalidad;
    dslocalidad = &(( (t_localidad *) *rw)[rowi]);
    //leer valor desde estructura obtenida de la BD    
	dslocalidad->localidad_id = atoi(PQgetvalue(res,rowi,0));
    strcpy( dslocalidad->nombre_localidad ,rtrim(PQgetvalue(res,rowi,1),' '));
}       
//----------------------------------------------------
//Copiar datos desde una variable de struct => puntero a obj_localidad
static void fillObjLocalidad(obj_localidad *p,  t_localidad rwitm)
{  
      p->info.localidad_id = rwitm.localidad_id;
	  strcpy( p->info.nombre_localidad,rwitm.nombre_localidad);
	  p->isNewObj = false; // marcar que ya existe correspondencia en la base de datos en saveObj
}
//----------------------------------------------------
//Copiar en arreglo dinamico de tipo obj_localidad
static void fillRowsLocalidad(void **list, int size,void *data)
{
     int i;
     obj_localidad *d;
     // pedir memoria para el listado en memoria de localidads obj_localidad
    *list = (obj_localidad **)malloc(sizeof(obj_localidad*)* size);
    for(i=0;i<size;++i)
    {
      d = localidad_new();
      fillObjLocalidad(d,((t_localidad *)data)[i]);
      ((obj_localidad **)*list)[i] = d;
    }
 }
//----------------------------------------------------
//Copiar las tuplas a una instancia de dataset:t_table
static void fill_dataset_localidad(t_table *t,void *data, int sz)
{
 int i;
 //pedir memoria para contener listado de registros en formato dataset_localidad.
 t->rows = malloc(sizeof(t_localidad)* sz);
 t->cant_rows=sz;//cantidad de filas
     for(i=0;i<sz;++i)
     {
      ((t_localidad *)t->rows)[i].localidad_id =((t_localidad *)data)[i].localidad_id;
      strcpy( ((t_localidad *)t->rows)[i].nombre_localidad,((t_localidad *)data)[i].nombre_localidad);
     }
}
//----------------------------------------------------
//ejecutar consulta SQL en la base y obtener result set para cargar en memoria, invocacion personalizada a un codigo generico.
static int exec_get_localidad(char *sql,void **rw)
{
  return exec_get_fromDB(sql,rw, sizeof(t_localidad),fillLocalidadFromDB);
}
//----------------------------------------------------
// implementacion para copiar toda la informacion segun un criterio ejecutado en la base de datos
static int findAll_localidadImpl(void *self,void **list, char *criteria)
{
  return findAllImpl(self,list, criteria, sizeof(t_localidad), ((t_table*)((obj_localidad*)self)->ds)->rows,fillLocalidadFromDB,fillRowsLocalidad);
}
//----------------------------------------------------
static bool getIsNewObj_Impl(void *self)
{
	obj_localidad *obj = this(self);
	return obj->isNewObj;
}
//----------------------------------------------------
// implementacion de metodos para localidad
static int find_localidadImpl(void *self, int k) // se debe pasar en orden de aparicion de las columnas claves 
{
   int size=0; void *data;  
   char *sql;
   obj_localidad *obj = this(self);
   //obtener cadena sql (select * from table where ...)las columnas claves estan igualadas a datos.   
   obj->info.localidad_id=k;//setear dato clave
   sql = (char*)getFindByKeySQL((t_object*)self);
   //ejecutar consulta sql de seleccion, con criterio where
   data = ((t_table*)obj->ds)->rows;   
   size = exec_get_localidad(sql,&data);
   //liberar cadena sql
   free(sql);
   // completar 
   fill_dataset_localidad(obj->ds,data,size);
   // setear datos a la instancia....
   if(size>0)
   	 fillObjLocalidad(obj,((t_localidad *)data)[0]);
   else
     size = -1;   
   return size;
}
//----------------------------------------------------
static bool saveObj_localidadImpl(void *self)
{
   obj_localidad *obj = this(self); 
   int newIdLocalidad;
   bool isNew_Obj = obj->getIsNewObj(self);
   bool retValue = saveObjImpl(self,&newIdLocalidad);
   if(isNew_Obj)
     obj->info.localidad_id = newIdLocalidad;
   return retValue;
}
//----------------------------------------------------
static void toString_localidadImpl(void *self)
{
     obj_localidad *self_o=this(self);
     obj_localidad *sup;     
     printf("localidad_id: %d  localidad:%s \n",self_o->info.localidad_id,self_o->info.nombre_localidad);
}
//----------------------------------------------------
//implementacion de getters
static int getLocalidadId_Impl(void *self)
{ 
  obj_localidad *obj = this(self);
  return obj->info.localidad_id;
}
//----------------------------------------------------
static char *getNombreLocalidad_Impl(void *self)
{
	obj_localidad *obj = this(self);
	return obj->info.nombre_localidad;	
}
//----------------------------------------------------
//implementacion setters
//----------------------------------------------------
static void setNombreLocalidad_Impl(void *self,char *nombre_localidad)
{ 
	obj_localidad *obj = this(self);
	strcpy(obj->info.nombre_localidad,nombre_localidad);
}
//----------------------------------------------------
static void getValueByPosImpl(void *self,char * cad, int pos)
{ 
   char field[MAX_WHERE_SQL];
   obj_localidad *obj = this(self);
   t_table *tt=obj->ds;
   if(pos==0)
     snprintf( field, MAX_WHERE_SQL,"%d", obj->info.localidad_id );
   if(pos==1)
     snprintf( field, MAX_WHERE_SQL,"'%s'", obj->info.nombre_localidad );
   strcat(cad,field);   
}
//----------------------------------------------------
static void *init_localidad(void *self)
{
  obj_localidad *obj = (obj_localidad *)self;   
  //setear valores default
  obj->info.localidad_id=0;
  CLEAR(obj->info.nombre_localidad,MAX);
  obj->ds  = &table_localidad;  
  obj->isNewObj = true;//marcar como objeto nuevo, si se crea nueva instancia
  obj->getValueByPos = getValueByPosImpl;
  // Inicializar handlers de getters y setters
  /// getters
  obj->getLocalidadId  	  = getLocalidadId_Impl;
  obj->getNombreLocalidad = getNombreLocalidad_Impl;  
  /// setters  
  obj->setNombreLocalidad = setNombreLocalidad_Impl;  
  //incializacion de la interfaz de la entidad
  obj->getIsNewObj =   getIsNewObj_Impl;
  obj->findbykey = find_localidadImpl;
  obj->findAll =   findAll_localidadImpl;
  obj->saveObj =   saveObj_localidadImpl; 
  obj->toString =   toString_localidadImpl;
  return obj;
}
//----------------------------------------------------
//constructor de localidad
obj_localidad *localidad_new()
{
  return (obj_localidad *)init_obj(sizeof(obj_localidad), init_localidad);
}
//----------------------------------------------------
