#include <string.h>
#include <errno.h>

#include "../../config/config.h"
#include "../../lib/utils/utils.h"
#include "../../lib/orm/orm.h"
#include "Escuela.h"

THIS(obj_Escuela)
//----------------------------------------------------
//Copiar a puntero de arreglo en posicion dada, desde un result set de base de datos.
static void fillEscuelaFromDB(void **rw , int rowi,PGresult *res)
{
    t_Escuela *dsEscuela;
    dsEscuela = &(( (t_Escuela *) *rw)[rowi]);
    //leer valor desde estructura obtenida de la BD    
	dsEscuela->Escuela_id = atoi(PQgetvalue(res,rowi,0));
	dsEscuela->circ_id = atoi(PQgetvalue(res,rowi,1));
    strcpy( dsEscuela->nombre_Escuela ,rtrim(PQgetvalue(res,rowi,2),' '));
    strcpy( dsEscuela->dir_Escuela ,rtrim(PQgetvalue(res,rowi,3),' '));
    dsEscuela->localidad_id = atoi(PQgetvalue(res,rowi,4));
}       
//----------------------------------------------------
//Copiar datos desde una variable de struct => puntero a obj_Escuela
static void fillObjEscuela(obj_Escuela *p,  t_Escuela rwitm)
{  
      p->info.Escuela_id = rwitm.Escuela_id;
      p->info.circ_id = rwitm.circ_id;
      p->info.localidad_id = rwitm.localidad_id;
	  strcpy( p->info.nombre_Escuela,rwitm.nombre_Escuela);
	  strcpy( p->info.dir_Escuela,rwitm.dir_Escuela);
	  p->isNewObj = false; // marcar que ya existe correspondencia en la base de datos en saveObj
}
//----------------------------------------------------
//Copiar en arreglo dinamico de tipo obj_Escuela
static void fillRowsEscuela(void **list, int size,void *data)
{
     int i;
     obj_Escuela *d;
     // pedir memoria para el listado en memoria de Escuelas obj_Escuela
    *list = (obj_Escuela **)malloc(sizeof(obj_Escuela*)* size);
    for(i=0;i<size;++i)
    {
      d = Escuela_new();
      fillObjEscuela(d,((t_Escuela *)data)[i]);
      ((obj_Escuela **)*list)[i] = d;
    }
 }
//----------------------------------------------------
//Copiar las tuplas a una instancia de dataset:t_table
static void fill_dataset_Escuela(t_table *t,void *data, int sz)
{
 int i;
 //pedir memoria para contener listado de registros en formato dataset_Escuela.
 t->rows = malloc(sizeof(t_Escuela)* sz);
 t->cant_rows=sz;//cantidad de filas
     for(i=0;i<sz;++i)
     {
      ((t_Escuela *)t->rows)[i].Escuela_id =((t_Escuela *)data)[i].Escuela_id;
      ((t_Escuela *)t->rows)[i].circ_id =((t_Escuela *)data)[i].circ_id;
      ((t_Escuela *)t->rows)[i].localidad_id =((t_Escuela *)data)[i].localidad_id;
      strcpy( ((t_Escuela *)t->rows)[i].nombre_Escuela,((t_Escuela *)data)[i].nombre_Escuela);
      strcpy( ((t_Escuela *)t->rows)[i].dir_Escuela,((t_Escuela *)data)[i].dir_Escuela);
     }
}
//----------------------------------------------------
//ejecutar consulta SQL en la base y obtener result set para cargar en memoria, invocacion personalizada a un codigo generico.
static int exec_get_Escuela(char *sql,void **rw)
{
  return exec_get_fromDB(sql,rw, sizeof(t_Escuela),fillEscuelaFromDB);
}
//----------------------------------------------------
// implementacion para copiar toda la informacion segun un criterio ejecutado en la base de datos
static int findAll_EscuelaImpl(void *self,void **list, char *criteria)
{
  return findAllImpl(self,list, criteria, sizeof(t_Escuela), ((t_table*)((obj_Escuela*)self)->ds)->rows,fillEscuelaFromDB,fillRowsEscuela);
}
//----------------------------------------------------
static bool getIsNewObj_Impl(void *self)
{
	obj_Escuela *obj = this(self);
	return obj->isNewObj;
}
//----------------------------------------------------
// implementacion de metodos para Escuela
static int find_EscuelaImpl(void *self, int k) // se debe pasar en orden de aparicion de las columnas claves 
{
   int size=0; void *data;  
   char *sql;
   obj_Escuela *obj = this(self);
   //obtener cadena sql (select * from table where ...)las columnas claves estan igualadas a datos.   
   obj->info.Escuela_id=k;//setear dato clave
   sql = (char*)getFindByKeySQL((t_object*)self);
   //ejecutar consulta sql de seleccion, con criterio where
   data = ((t_table*)obj->ds)->rows;   
   size = exec_get_Escuela(sql,&data);
   //liberar cadena sql
   free(sql);
   // completar 
   fill_dataset_Escuela(obj->ds,data,size);
   // setear datos a la instancia....
   if(size>0)
   	 fillObjEscuela(obj,((t_Escuela *)data)[0]);
   else
     size = -1;   
   return size;
}
//----------------------------------------------------
static bool saveObj_EscuelaImpl(void *self)
{
   obj_Escuela *obj = this(self); 
   int newIdEscuela;
   bool isNew_Obj = obj->getIsNewObj(self);
   bool retValue = saveObjImpl(self,&newIdEscuela);
   if(isNew_Obj)
     obj->info.Escuela_id = newIdEscuela;
   return retValue;
}
//----------------------------------------------------
static void toString_EscuelaImpl(void *self)
{
     obj_Escuela *self_o=this(self);
     obj_Escuela *sup;     
     printf("Escuela_id: %d  Escuela:%s - direccion: %s\n",self_o->info.Escuela_id,self_o->info.nombre_Escuela,self_o->info.dir_Escuela);
}
//----------------------------------------------------
//implementacion de getters
static int getEscuelaId_Impl(void *self)
{ 
  obj_Escuela *obj = this(self);
  return obj->info.Escuela_id;
}
//----------------------------------------------------
static char *getNombreEscuela_Impl(void *self)
{
	obj_Escuela *obj = this(self);
	return obj->info.nombre_Escuela;	
}
//----------------------------------------------------
//implementacion setters
//----------------------------------------------------
static void setNombreEscuela_Impl(void *self,char *nombre_Escuela)
{ 
	obj_Escuela *obj = this(self);
	strcpy(obj->info.nombre_Escuela,nombre_Escuela);
}
//----------------------------------------------------
static void getValueByPosImpl(void *self,char * cad, int pos)
{ 
   char field[MAX_WHERE_SQL];
   obj_Escuela *obj = this(self);
   t_table *tt=obj->ds;
   if(pos==0)
     snprintf( field, MAX_WHERE_SQL,"%d", obj->info.Escuela_id );
   if(pos==1)
     snprintf( field, MAX_WHERE_SQL,"'%s'", obj->info.nombre_Escuela );
   strcat(cad,field);   
}
//----------------------------------------------------
static void *init_Escuela(void *self)
{
  obj_Escuela *obj = (obj_Escuela *)self;   
  //setear valores default
  obj->info.Escuela_id=0;
  CLEAR(obj->info.nombre_Escuela,MAX);
  obj->ds  = &table_Escuela;  
  obj->isNewObj = true;//marcar como objeto nuevo, si se crea nueva instancia
  obj->getValueByPos = getValueByPosImpl;
  // Inicializar handlers de getters y setters
  /// getters
  obj->getEscuelaId  	  = getEscuelaId_Impl;
  obj->getNombreEscuela = getNombreEscuela_Impl;  
  /// setters  
  obj->setNombreEscuela = setNombreEscuela_Impl;  
  //incializacion de la interfaz de la entidad
  obj->getIsNewObj =   getIsNewObj_Impl;
  obj->findbykey = find_EscuelaImpl;
  obj->findAll =   findAll_EscuelaImpl;
  obj->saveObj =   saveObj_EscuelaImpl; 
  obj->toString =   toString_EscuelaImpl;
  return obj;
}
//----------------------------------------------------
//constructor de Escuela
obj_Escuela *Escuela_new()
{
  return (obj_Escuela *)init_obj(sizeof(obj_Escuela), init_Escuela);
}
//----------------------------------------------------
